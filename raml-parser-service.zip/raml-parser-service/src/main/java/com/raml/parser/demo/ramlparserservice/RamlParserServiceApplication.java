package com.raml.parser.demo.ramlparserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RamlParserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RamlParserServiceApplication.class, args);
	}
}
